import java.util.*;

public class ExamCentres {
	static short LKO = 10;
	static short CNB = 20;
	static short AGC = 30;
	static short ALD = 40;
	static short VNS = 50;
}
