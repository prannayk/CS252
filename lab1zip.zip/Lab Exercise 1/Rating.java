public enum Rating {
	A, UA, U
}